from contextlib import asynccontextmanager
from datetime import datetime
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request

from app.cache import (
    get_cache,
    get_server_cache,
    initialize_cache,
)
from app.config import load_servers
from app.services.monitor import (
    check_all_server_apis,
    check_all_server_systems,
    check_all_servers,
    check_single_server_all,
    check_single_server_api,
    check_single_server_system,
)


NAIROBI_TIMEZONE = ZoneInfo("Africa/Nairobi")

servers = load_servers()

initialize_cache(servers)


def find_server(server_id: str) -> dict:
    """
    Find a configured server using its ID.

    Raises a 404 response if the server does not exist.
    """

    server = next(
        (
            item
            for item in servers
            if item["id"] == server_id
        ),
        None,
    )

    if server is None:
        raise HTTPException(
            status_code=404,
            detail=f"Server '{server_id}' was not found",
        )

    return server


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Run an initial API and system check when the application starts.

    Failed checks are stored in the in-memory cache and should not
    prevent the dashboard from starting.
    """

    check_all_servers(servers)

    yield


app = FastAPI(
    title="IMAL Infrastructure Monitor",
    version="1.0.0",
    lifespan=lifespan,
)

app.mount(
    "/static",
    StaticFiles(directory="app/static"),
    name="static",
)

templates = Jinja2Templates(
    directory="app/templates",
)


@app.get("/health")
def health_check() -> dict:
    """
    Health endpoint for Docker and external monitoring.
    """

    return {
        "status": "healthy",
        "application": "IMAL Infrastructure Monitor",
        "timestamp": datetime.now(
            NAIROBI_TIMEZONE
        ).isoformat(timespec="seconds"),
    }


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    """
    Render the monitoring dashboard using the current cached values.
    """

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "title": "IMAL Infrastructure Monitor",
            "servers": get_cache(),
        },
    )


@app.get("/api/status")
def get_all_statuses() -> dict:
    """
    Return the latest cached API and system status for every server.
    """

    return {
        "servers": get_cache(),
    }


@app.get("/api/status/{server_id}")
def get_single_server_status(
    server_id: str,
) -> dict:
    """
    Return the latest cached status for one server.
    """

    cached_server = get_server_cache(server_id)

    if cached_server is None:
        raise HTTPException(
            status_code=404,
            detail=f"Server '{server_id}' was not found",
        )

    return cached_server


@app.post("/api/check")
def run_all_checks() -> dict:
    """
    Run API and system checks against all configured servers.
    """

    results = check_all_servers(servers)

    return {
        "message": "All API and system checks completed",
        "results": results,
    }


@app.post("/api/check/api")
def run_all_api_checks() -> dict:
    """
    Run only the IMAL account API checks for all servers.
    """

    results = check_all_server_apis(servers)

    return {
        "message": "All API checks completed",
        "results": results,
    }


@app.post("/api/check/system")
def run_all_system_checks() -> dict:
    """
    Run only the SSH system-resource checks for all servers.
    """

    results = check_all_server_systems(servers)

    return {
        "message": "All system checks completed",
        "results": results,
    }


@app.post("/api/check/{server_id}")
def run_single_server_checks(
    server_id: str,
) -> dict:
    """
    Run both API and system checks for one server.
    """

    server = find_server(server_id)

    return check_single_server_all(server)


@app.post("/api/check/{server_id}/api")
def run_single_server_api_check(
    server_id: str,
) -> dict:
    """
    Run only the IMAL account API check for one server.
    """

    server = find_server(server_id)

    return check_single_server_api(server)


@app.post("/api/check/{server_id}/system")
def run_single_server_system_check(
    server_id: str,
) -> dict:
    """
    Run only the SSH system-resource check for one server.
    """

    server = find_server(server_id)

    return check_single_server_system(server)